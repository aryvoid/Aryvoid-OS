import { useState } from 'react';
import {
  ClipboardList,
  ListTodo,
  Shield,
  TrendingUp,
  BookOpen,
  Settings,
  Menu,
  X,
} from 'lucide-react';

interface Props {
  currentPage: string;
  onNavigate: (page: string) => void;
  onVoiceCommand?: (cmd: string) => void;
}

const navItems = [
  { id: 'routine', label: 'ROUTINE', icon: ClipboardList },
  { id: 'todo', label: 'TO-DO LIST', icon: ListTodo },
  { id: 'vault', label: 'VAULT', icon: Shield },
  { id: 'progress', label: 'PROGRESS ERA', icon: TrendingUp },
  { id: 'journal', label: 'JOURNAL', icon: BookOpen },
  { id: 'settings', label: 'SETTINGS', icon: Settings },
];

export function Sidebar({ currentPage, onNavigate }: Props) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (id: string) => {
    onNavigate(id);
    setMobileOpen(false);
  };

  const navContent = (
    <>
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = currentPage === item.id;
        return (
          <button
            key={item.id}
            onClick={() => handleNav(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 text-left group ${
              isActive
                ? 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-400'
                : 'border border-transparent text-cyan-600/60 hover:text-cyan-400 hover:bg-cyan-500/5 hover:border-cyan-500/20'
            }`}
          >
            <Icon
              size={18}
              className={`transition-transform group-hover:scale-110 ${
                isActive ? 'text-cyan-400' : ''
              }`}
            />
            <span className="text-xs tracking-wider font-medium">{item.label}</span>
            {isActive && (
              <div className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(0,212,255,0.6)]" />
            )}
          </button>
        );
      })}
    </>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="sidebar-desktop fixed left-0 top-0 h-full w-64 flex-col gap-2 p-4 glass-strong z-40">
        <div className="flex items-center gap-3 px-4 py-4 mb-4">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
            <span className="text-cyan-400 font-bold text-sm">A</span>
          </div>
          <div>
            <div className="text-cyan-400 text-sm font-bold tracking-widest glow-text">
              ARYVOID
            </div>
            <div className="text-cyan-600/40 text-[10px] tracking-[0.2em]">
              OPERATING SYSTEM
            </div>
          </div>
        </div>
        <div className="flex-1 flex flex-col gap-1 overflow-y-auto">
          {navContent}
        </div>
        <div className="mt-auto pt-4 border-t border-cyan-500/10">
          <div className="text-cyan-700/40 text-[10px] tracking-wider text-center">
            V2.0 // OFFLINE MODE
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="sidebar-mobile fixed top-0 left-0 right-0 h-14 glass-strong z-40 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
            <span className="text-cyan-400 font-bold text-xs">A</span>
          </div>
          <span className="text-cyan-400 text-xs font-bold tracking-widest">ARYVOID</span>
        </div>
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="text-cyan-400 p-2"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileOpen && (
        <div className="sidebar-mobile fixed inset-0 z-50 bg-black/80" onClick={() => setMobileOpen(false)}>
          <div
            className="absolute right-0 top-0 h-full w-64 glass-strong p-4 flex flex-col gap-1"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-4 mb-4">
              <span className="text-cyan-400 text-sm font-bold tracking-widest">MENU</span>
              <button onClick={() => setMobileOpen(false)} className="text-cyan-400 p-1">
                <X size={18} />
              </button>
            </div>
            {navContent}
          </div>
        </div>
      )}

      {/* Mobile Bottom Nav */}
      <nav className="sidebar-mobile fixed bottom-0 left-0 right-0 h-16 glass-strong z-40 flex items-center justify-around px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`flex flex-col items-center gap-0.5 p-2 rounded-lg transition-all ${
                isActive ? 'text-cyan-400' : 'text-cyan-700/40'
              }`}
            >
              <Icon size={18} />
              <span className="text-[8px] tracking-wider">{item.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
}
