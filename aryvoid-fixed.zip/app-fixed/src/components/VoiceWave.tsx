interface Props {
  isActive: boolean;
  isListening?: boolean;
}

export function VoiceWave({ isActive, isListening }: Props) {
  if (!isActive && !isListening) return null;

  const color = isListening ? '#00ff88' : '#00d4ff';
  const label = isListening ? 'LISTENING' : 'SPEAKING';

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2">
      <div className="text-xs tracking-[0.3em]" style={{ color }}>
        {label}
      </div>
      <div className="flex items-center gap-1 h-8">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="voice-wave-bar rounded-full"
            style={{
              width: '3px',
              background: color,
              animationDelay: `${i * 0.08}s`,
              animationDuration: `${0.4 + Math.random() * 0.3}s`,
              opacity: 0.8,
            }}
          />
        ))}
      </div>
    </div>
  );
}
