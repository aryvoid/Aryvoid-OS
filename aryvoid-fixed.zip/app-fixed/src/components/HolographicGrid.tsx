import { useEffect, useRef } from 'react';

interface Props {
  intensity?: number;
}

export function HolographicGrid({ intensity = 1 }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || intensity === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      time += 0.008;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const gridSize = 60;
      const perspective = 0.6;
      const centerY = canvas.height * 0.55;

      // Vertical lines with perspective
      for (let i = -20; i <= 20; i++) {
        const x = canvas.width / 2 + i * gridSize;
        const fadeStart = canvas.height * 0.3;
        ctx.beginPath();
        ctx.moveTo(x, fadeStart);
        ctx.lineTo(canvas.width / 2 + i * gridSize * 4, canvas.height);
        ctx.strokeStyle = `rgba(0, 212, 255, ${0.04 * intensity * Math.max(0, 1 - Math.abs(i) / 25)})`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Horizontal lines with perspective
      for (let i = 0; i < 25; i++) {
        const y = centerY + i * gridSize * (1 + i * perspective * 0.15);
        if (y > canvas.height) break;
        const alpha = 0.06 * intensity * (1 - i / 30) * (0.7 + 0.3 * Math.sin(time + i * 0.3));
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.strokeStyle = `rgba(0, 212, 255, ${Math.max(0, alpha)})`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Floating particles
      for (let i = 0; i < 25; i++) {
        const px = ((Math.sin(time * 0.5 + i * 2.3) * 0.5 + 0.5) * canvas.width);
        const py = ((Math.cos(time * 0.3 + i * 1.7) * 0.5 + 0.5) * canvas.height);
        const size = 1 + Math.sin(time + i) * 0.5;
        const alpha = 0.3 * intensity * (0.5 + 0.5 * Math.sin(time * 2 + i));
        ctx.beginPath();
        ctx.arc(px, py, size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 212, 255, ${alpha})`;
        ctx.fill();
      }

      // Horizon glow
      const horizonGrad = ctx.createLinearGradient(0, centerY - 50, 0, centerY + 100);
      horizonGrad.addColorStop(0, `rgba(0, 212, 255, 0)`);
      horizonGrad.addColorStop(0.5, `rgba(0, 212, 255, ${0.03 * intensity})`);
      horizonGrad.addColorStop(1, `rgba(0, 212, 255, 0)`);
      ctx.fillStyle = horizonGrad;
      ctx.fillRect(0, centerY - 50, canvas.width, 150);

      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [intensity]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}
