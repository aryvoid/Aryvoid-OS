import { useState, useEffect, useCallback, useRef } from 'react';
import { HolographicGrid } from '@/components/HolographicGrid';
import { ScanLines } from '@/components/ScanLines';
import { VoiceWave } from '@/components/VoiceWave';
import { Sidebar } from '@/components/Sidebar';
import { LoginPage } from '@/pages/LoginPage';
import { RoutinePage } from '@/pages/RoutinePage';
import { TodoPage } from '@/pages/TodoPage';
import { VaultPage, type VaultEntry } from '@/pages/VaultPage';
import { ProgressPage } from '@/pages/ProgressPage';
import { JournalPage, type JournalEntry } from '@/pages/JournalPage';
import { SettingsPage } from '@/pages/SettingsPage';
import { useVoice } from '@/hooks/useVoice';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getTodayKey, isMonday, isSunday } from '@/hooks/useLocalStorage';
import './App.css';

interface RoutineTask {
  id: string;
  text: string;
  officeOnly?: boolean;
}

interface TodoTask {
  id: string;
  text: string;
  category: 'urgent' | 'important' | 'later';
}

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentPage, setCurrentPage] = useState('routine');

  // Settings state
  const [waterGoal, setWaterGoal] = useLocalStorage('aryvoid_water_goal', 2.5);
  const [wakeUpTime, setWakeUpTime] = useLocalStorage('aryvoid_wakeup', '06:00');
  const [sleepTime, setSleepTime] = useLocalStorage('aryvoid_sleep', '22:00');
  const [voiceEnabled, setVoiceEnabled] = useLocalStorage('aryvoid_voice', true);
  const [listenEnabled, setListenEnabled] = useLocalStorage('aryvoid_listen', false);
  const [effects3D, setEffects3D] = useLocalStorage('aryvoid_3d', true);
  const [themeIntensity, setThemeIntensity] = useLocalStorage('aryvoid_theme', 3);
  const [lastBackup, setLastBackup] = useLocalStorage<string | null>('aryvoid_backup', null);

  // Data state
  const [routineData, setRoutineData] = useLocalStorage<Record<string, boolean>>('aryvoid_routine', {});
  const [waterData, setWaterData] = useLocalStorage<Record<string, number>>('aryvoid_water', {});
  const [history, setHistory] = useLocalStorage<Record<string, number>>('aryvoid_history', {});
  const [routineTasks, setRoutineTasks] = useLocalStorage<RoutineTask[]>('aryvoid_routine_tasks', []);
  const [todoTasks, setTodoTasks] = useLocalStorage<TodoTask[]>('aryvoid_todo_tasks', []);
  const [todoCompleted, setTodoCompleted] = useLocalStorage<string[]>('aryvoid_todo_done', []);
  const [vaultEntries, setVaultEntries] = useLocalStorage<VaultEntry[]>('aryvoid_vault', [
    { id: 'demo', title: 'Instagram', username: 'example@email.com', password: btoa('password123') },
  ]);
  const [journalEntries, setJournalEntries] = useLocalStorage<JournalEntry[]>('aryvoid_journal', []);
  const [lastDate, setLastDate] = useLocalStorage('aryvoid_lastdate', '');

  const voice = useVoice(voiceEnabled, listenEnabled);
  const loginSpoken = useRef(false);

  // Daily reset
  useEffect(() => {
    const today = getTodayKey();
    if (lastDate && lastDate !== today) {
      // Save yesterday's progress
      const yesterdayProgress = calculateProgress();
      setHistory((h) => ({ ...h, [lastDate]: yesterdayProgress }));
      // Reset routine for new day
      setRoutineData({});
      // Reset water
      setWaterData({});
    }
    setLastDate(today);
  }, [lastDate]);

  // Save today's progress periodically
  useEffect(() => {
    const interval = setInterval(() => {
      const today = getTodayKey();
      const progress = calculateProgress();
      setHistory((h) => ({ ...h, [today]: progress }));
    }, 30000);
    return () => clearInterval(interval);
  }, [routineData, waterData, waterGoal]);

  const calculateProgress = () => {
    // Calculate based on all visible tasks
    const isRest = isMonday();
    const isSun = isSunday();
    const defaultTaskIds = [
      'wake', 'water', 'exercise', 'bath', 'breakfast', 'study1',
      'chores', 'office', 'ytask', 'owork', 'mindset', 'walk',
      'coding', 'deepstudy', 'journal', 'dinner', 'review', 'sleep',
    ];
    const restIds = ['wake', 'water', 'exercise', 'bath', 'study1', 'chores', 'mindset', 'deepstudy', 'journal', 'sleep'];
    const officeIds = ['office', 'ytask', 'owork', 'coding'];

    let activeIds = defaultTaskIds;
    if (isRest) activeIds = restIds;
    else if (isSun) activeIds = defaultTaskIds.filter(id => !officeIds.includes(id));

    // Add custom tasks
    routineTasks.forEach(t => activeIds.push(t.id));

    const completed = activeIds.filter(id => routineData[id]).length;
    const total = activeIds.length;
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  };

  // Voice commands handler
  const handleVoiceCommand = useCallback(
    (cmd: string) => {
      if (cmd.includes('open routine') || cmd.includes('routine')) setCurrentPage('routine');
      else if (cmd.includes('open to-do') || cmd.includes('todo') || cmd.includes('to do')) setCurrentPage('todo');
      else if (cmd.includes('open vault') || cmd.includes('vault')) setCurrentPage('vault');
      else if (cmd.includes('open progress') || cmd.includes('progress')) setCurrentPage('progress');
      else if (cmd.includes('open journal') || cmd.includes('journal')) setCurrentPage('journal');
      else if (cmd.includes('open settings') || cmd.includes('settings')) setCurrentPage('settings');
      else if (cmd.includes("what's my progress") || cmd.includes('my progress')) {
        const pct = calculateProgress();
        voice.speak(`Your current progress is ${pct} percent.`);
      } else if (cmd.includes('system status')) {
        voice.speak('All systems operational. ARYVOID is running at optimal efficiency.');
      }
    },
    [voice]
  );

  // Start voice listening when enabled
  useEffect(() => {
    if (listenEnabled && isLoggedIn) {
      voice.startListening(handleVoiceCommand);
    } else {
      voice.stopListening();
    }
    return () => voice.stopListening();
  }, [listenEnabled, isLoggedIn, handleVoiceCommand]);

  // Welcome voice on login
  useEffect(() => {
    if (isLoggedIn && voiceEnabled && !loginSpoken.current) {
      loginSpoken.current = true;
      setTimeout(() => {
        voice.speak('Welcome back, Aryvoid. Systems online. All functions operational.');
      }, 500);
    }
  }, [isLoggedIn, voiceEnabled]);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  // Routine handlers
  const toggleRoutineTask = (id: string) => {
    setRoutineData((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      return next;
    });
    if (voiceEnabled) {
      const isComplete = !routineData[id];
      voice.speak(isComplete ? 'Task completed.' : 'Task unmarked.');
    }
  };

  const updateWater = (amount: number) => {
    const today = getTodayKey();
    setWaterData((prev) => {
      const current = prev[today] || 0;
      const next = Math.max(0, current + amount);
      return { ...prev, [today]: next };
    });
    if (voiceEnabled) {
      voice.speak(amount > 0 ? `Water intake updated. Added ${amount * 1000} milliliters.` : 'Water intake reduced.');
    }
  };

  // Todo handlers
  const toggleTodo = (id: string) => {
    setTodoCompleted((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  };

  // Vault handlers
  const addVaultEntry = (entry: Omit<VaultEntry, 'id'>) => {
    const newEntry: VaultEntry = { ...entry, id: Date.now().toString() };
    setVaultEntries((prev) => [...prev, newEntry]);
    if (voiceEnabled) voice.speak('Vault entry added.');
  };
  const editVaultEntry = (id: string, entry: Omit<VaultEntry, 'id'>) => {
    setVaultEntries((prev) => prev.map((e) => (e.id === id ? { ...entry, id } : e)));
    if (voiceEnabled) voice.speak('Vault entry updated.');
  };
  const deleteVaultEntry = (id: string) => {
    setVaultEntries((prev) => prev.filter((e) => e.id !== id));
    if (voiceEnabled) voice.speak('Vault entry deleted.');
  };

  // Journal handlers
  const addJournalEntry = (content: string, mood: number) => {
    const entry: JournalEntry = {
      id: Date.now().toString(),
      content,
      mood,
      timestamp: Date.now(),
    };
    setJournalEntries((prev) => [entry, ...prev]);
    if (voiceEnabled) voice.speak('Journal entry saved.');
  };
  const editJournalEntry = (id: string, content: string, mood: number) => {
    setJournalEntries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, content, mood } : e))
    );
    if (voiceEnabled) voice.speak('Journal entry updated.');
  };
  const deleteJournalEntry = (id: string) => {
    setJournalEntries((prev) => prev.filter((e) => e.id !== id));
    if (voiceEnabled) voice.speak('Journal entry deleted.');
  };

  // Settings handlers
  const addRoutineTask = (text: string, officeOnly: boolean) => {
    const task: RoutineTask = { id: `custom_${Date.now()}`, text, officeOnly };
    setRoutineTasks((prev) => [...prev, task]);
    if (voiceEnabled) voice.speak('Routine task added.');
  };
  const deleteRoutineTask = (id: string) => {
    setRoutineTasks((prev) => prev.filter((t) => t.id !== id));
    if (voiceEnabled) voice.speak('Routine task removed.');
  };
  const addTodoTask = (text: string, category: 'urgent' | 'important' | 'later') => {
    const task: TodoTask = { id: `todo_${Date.now()}`, text, category };
    setTodoTasks((prev) => [...prev, task]);
    if (voiceEnabled) voice.speak('To-do task added.');
  };
  const deleteTodoTask = (id: string) => {
    setTodoTasks((prev) => prev.filter((t) => t.id !== id));
    setTodoCompleted((prev) => prev.filter((x) => x !== id));
    if (voiceEnabled) voice.speak('To-do task removed.');
  };

  // Export/Import/Reset
  const handleExport = () => {
    const data = {
      routineData,
      waterData,
      history,
      routineTasks,
      todoTasks,
      todoCompleted,
      vaultEntries,
      journalEntries,
      settings: { waterGoal, wakeUpTime, sleepTime, voiceEnabled, listenEnabled, effects3D, themeIntensity },
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aryvoid_backup_${getTodayKey()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setLastBackup(new Date().toLocaleString());
    if (voiceEnabled) voice.speak('Data exported successfully.');
  };

  const handleImport = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.routineData) setRoutineData(data.routineData);
      if (data.waterData) setWaterData(data.waterData);
      if (data.history) setHistory(data.history);
      if (data.routineTasks) setRoutineTasks(data.routineTasks);
      if (data.todoTasks) setTodoTasks(data.todoTasks);
      if (data.todoCompleted) setTodoCompleted(data.todoCompleted);
      if (data.vaultEntries) setVaultEntries(data.vaultEntries);
      if (data.journalEntries) setJournalEntries(data.journalEntries);
      if (data.settings) {
        const s = data.settings;
        setWaterGoal(s.waterGoal ?? 2.5);
        setWakeUpTime(s.wakeUpTime ?? '06:00');
        setSleepTime(s.sleepTime ?? '22:00');
        setVoiceEnabled(s.voiceEnabled ?? true);
        setListenEnabled(s.listenEnabled ?? false);
        setEffects3D(s.effects3D ?? true);
        setThemeIntensity(s.themeIntensity ?? 3);
      }
      if (voiceEnabled) voice.speak('Data imported successfully.');
      return true;
    } catch {
      return false;
    }
  };

  const handleReset = () => {
    setRoutineData({});
    setWaterData({});
    setHistory({});
    setRoutineTasks([]);
    setTodoTasks([]);
    setTodoCompleted([]);
    setVaultEntries([]);
    setJournalEntries([]);
    setWaterGoal(2.5);
    setWakeUpTime('06:00');
    setSleepTime('22:00');
    setVoiceEnabled(true);
    setListenEnabled(false);
    setEffects3D(true);
    setThemeIntensity(3);
    setLastBackup(null);
    if (voiceEnabled) voice.speak('All data has been reset. System restored to defaults.');
  };

  // Convert todo tasks to the format expected by TodoPage
  const allTodoTasks = todoTasks.map((t) => ({
    ...t,
    category: todoCompleted.includes(t.id)
      ? ('done' as const)
      : t.category,
  }));

  const renderPage = () => {
    switch (currentPage) {
      case 'routine':
        return (
          <RoutinePage
            routineData={routineData}
            waterData={waterData}
            waterGoal={waterGoal}
            customTasks={routineTasks}
            onToggleTask={toggleRoutineTask}
            onUpdateWater={updateWater}
          />
        );
      case 'todo':
        return (
          <TodoPage
            tasks={allTodoTasks}
            completedIds={todoCompleted}
            onToggle={toggleTodo}
          />
        );
      case 'vault':
        return (
          <VaultPage
            entries={vaultEntries}
            onAdd={addVaultEntry}
            onEdit={editVaultEntry}
            onDelete={deleteVaultEntry}
          />
        );
      case 'progress':
        return (
          <ProgressPage
            routineData={routineData}
            waterData={waterData}
            waterGoal={waterGoal}
            history={history}
          />
        );
      case 'journal':
        return (
          <JournalPage
            entries={journalEntries}
            onAdd={addJournalEntry}
            onEdit={editJournalEntry}
            onDelete={deleteJournalEntry}
          />
        );
      case 'settings':
        return (
          <SettingsPage
            waterGoal={waterGoal}
            wakeUpTime={wakeUpTime}
            sleepTime={sleepTime}
            voiceEnabled={voiceEnabled}
            listenEnabled={listenEnabled}
            effects3D={effects3D}
            themeIntensity={themeIntensity}
            routineTasks={routineTasks}
            todoTasks={todoTasks}
            lastBackup={lastBackup}
            onSetWaterGoal={setWaterGoal}
            onSetWakeUpTime={setWakeUpTime}
            onSetSleepTime={setSleepTime}
            onToggleVoice={() => setVoiceEnabled((v: boolean) => !v)}
            onToggleListen={() => setListenEnabled((v: boolean) => !v)}
            onToggle3D={() => setEffects3D((v: boolean) => !v)}
            onSetThemeIntensity={setThemeIntensity}
            onAddRoutineTask={addRoutineTask}
            onDeleteRoutineTask={deleteRoutineTask}
            onAddTodoTask={addTodoTask}
            onDeleteTodoTask={deleteTodoTask}
            onExport={handleExport}
            onImport={handleImport}
            onReset={handleReset}
          />
        );
      default:
        return null;
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-black text-white relative scan-lines screen-flicker">
        <HolographicGrid intensity={themeIntensity} />
        <ScanLines />
        <LoginPage
          onLogin={handleLogin}
          speak={voice.speak}
          voiceEnabled={voiceEnabled}
        />
        <VoiceWave isActive={voice.isSpeaking} isListening={voice.isListening} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white relative scan-lines screen-flicker">
      <HolographicGrid intensity={themeIntensity} />
      <ScanLines />

      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onVoiceCommand={handleVoiceCommand}
      />

      <main className="main-content relative z-10 min-h-screen md:pl-64 pt-14 md:pt-0">
        <div className="p-4 md:p-8 max-w-5xl mx-auto">
          {renderPage()}
        </div>
      </main>

      <VoiceWave isActive={voice.isSpeaking} isListening={voice.isListening} />

      {/* Floating particles */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="float-particle absolute rounded-full"
            style={{
              width: `${2 + Math.random() * 4}px`,
              height: `${2 + Math.random() * 4}px`,
              background: 'rgba(0, 212, 255, 0.2)',
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${5 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
