import { useMemo, useRef, useEffect } from 'react';
import { TrendingUp, Target, Droplets, Zap, Flame, Trophy, BarChart3 } from 'lucide-react';
import { getTodayKey } from '@/hooks/useLocalStorage';

interface Props {
  routineData: Record<string, boolean>;
  waterData: Record<string, number>;
  waterGoal: number;
  history: Record<string, number>;
}

export function ProgressPage({ routineData, waterData, waterGoal, history }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const today = getTodayKey();
  const todayWater = waterData[today] || 0;

  const allRoutineIds = Object.keys(routineData);
  const completedToday = allRoutineIds.filter((id) => routineData[id]).length;
  const totalToday = allRoutineIds.length;
  const todayPercent = totalToday > 0 ? Math.round((completedToday / totalToday) * 100) : 0;

  const weekData = useMemo(() => {
    const days: { day: string; percent: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();
      const percent = history[key] || 0;
      days.push({ day: dayName, percent });
    }
    return days;
  }, [history]);

  const streak = useMemo(() => {
    let current = 0;
    let best = 0;
    let temp = 0;
    for (let i = 0; i < 365; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString().split('T')[0];
      const pct = history[key] || 0;
      if (pct >= 80) {
        temp++;
        if (i === 0) current = temp;
      } else {
        if (i === 0) current = 0;
        best = Math.max(best, temp);
        temp = 0;
      }
    }
    best = Math.max(best, temp, current);
    return { current, best };
  }, [history]);

  const monthRate = useMemo(() => {
    const now = new Date();
    let total = 0;
    let count = 0;
    for (let i = 0; i < 30; i++) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      const key = d.toISOString().split('T')[0];
      if (history[key] !== undefined) {
        total += history[key];
        count++;
      }
    }
    return count > 0 ? Math.round(total / count) : 0;
  }, [history]);

  const efficiency = useMemo(() => {
    const score = todayPercent;
    if (score >= 95) return { grade: 'S', label: 'PERFECT EXECUTION', color: '#00d4ff' };
    if (score >= 85) return { grade: 'A', label: 'HIGHLY EFFICIENT', color: '#00ff88' };
    if (score >= 70) return { grade: 'B', label: 'ABOVE AVERAGE', color: '#88ff00' };
    if (score >= 50) return { grade: 'C', label: 'ACCEPTABLE', color: '#ffcc00' };
    if (score >= 30) return { grade: 'D', label: 'NEEDS IMPROVEMENT', color: '#ff6600' };
    return { grade: 'F', label: 'CRITICAL', color: '#ff0044' };
  }, [todayPercent]);

  // Weekly bar chart canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);

    const w = rect.width;
    const h = rect.height;
    const padding = { top: 20, right: 20, bottom: 30, left: 30 };
    const chartW = w - padding.left - padding.right;
    const chartH = h - padding.top - padding.bottom;

    ctx.clearRect(0, 0, w, h);

    // Grid
    ctx.strokeStyle = 'rgba(0, 212, 255, 0.08)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 4; i++) {
      const y = padding.top + (chartH / 4) * i;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(w - padding.right, y);
      ctx.stroke();
    }

    // Bars
    const barWidth = chartW / weekData.length * 0.6;
    const spacing = chartW / weekData.length;

    weekData.forEach((d, i) => {
      const x = padding.left + spacing * i + spacing / 2;
      const barH = (d.percent / 100) * chartH;
      const y = padding.top + chartH - barH;

      // Bar gradient
      const grad = ctx.createLinearGradient(0, y, 0, y + barH);
      grad.addColorStop(0, 'rgba(0, 212, 255, 0.8)');
      grad.addColorStop(1, 'rgba(0, 128, 255, 0.3)');
      ctx.fillStyle = grad;
      ctx.roundRect(x - barWidth / 2, y, barWidth, barH, 4);
      ctx.fill();

      // Day label
      ctx.fillStyle = 'rgba(0, 212, 255, 0.5)';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(d.day, x, h - 8);

      // Percent label
      if (d.percent > 0) {
        ctx.fillStyle = 'rgba(0, 212, 255, 0.7)';
        ctx.font = 'bold 9px sans-serif';
        ctx.fillText(`${d.percent}%`, x, y - 4);
      }
    });

    // Y-axis labels
    ctx.fillStyle = 'rgba(0, 212, 255, 0.3)';
    ctx.font = '9px sans-serif';
    ctx.textAlign = 'right';
    for (let i = 0; i <= 4; i++) {
      const y = padding.top + (chartH / 4) * i;
      ctx.fillText(`${100 - i * 25}%`, padding.left - 6, y + 3);
    }
  }, [weekData]);

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h2 className="text-xl font-bold tracking-wider text-cyan-400 glow-text flex items-center gap-3">
          <TrendingUp size={24} />
          PROGRESS ERA
        </h2>
        <p className="text-cyan-600/40 text-xs tracking-wider mt-1">
          ANALYTICAL PERFORMANCE DASHBOARD
        </p>
      </div>

      {/* Main Progress Ring */}
      <div className="glass rounded-xl p-6 flex flex-col md:flex-row items-center gap-8 glow-cyan-sm">
        <div className="relative w-48 h-48 flex-shrink-0">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 200 200">
            <circle cx="100" cy="100" r="85" fill="none" stroke="rgba(0,212,255,0.08)" strokeWidth="10" />
            <circle cx="100" cy="100" r="75" fill="none" stroke="rgba(0,212,255,0.05)" strokeWidth="4" />
            <circle
              cx="100" cy="100" r="85" fill="none" stroke="#00d4ff"
              strokeWidth="10" strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 85}`}
              strokeDashoffset={`${2 * Math.PI * 85 * (1 - todayPercent / 100)}`}
              className="progress-ring-circle"
              style={{ filter: 'drop-shadow(0 0 10px rgba(0,212,255,0.3))' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-4xl font-bold text-cyan-400">{todayPercent}%</span>
            <span className="text-cyan-600/40 text-[10px] tracking-wider mt-1">TODAY</span>
          </div>
        </div>

        <div className="flex-1 space-y-4 w-full">
          <div className="flex items-center gap-4">
            <div
              className="text-5xl font-bold"
              style={{ color: efficiency.color, textShadow: `0 0 20px ${efficiency.color}40` }}
            >
              {efficiency.grade}
            </div>
            <div>
              <div className="text-cyan-100 text-sm font-bold tracking-wider">
                EFFICIENCY RATING
              </div>
              <div className="text-xs tracking-wider" style={{ color: efficiency.color }}>
                {efficiency.label}
              </div>
            </div>
          </div>

          <div className="h-px bg-cyan-500/10" />

          <div className="grid grid-cols-2 gap-3">
            <div className="glass rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <Target size={12} className="text-cyan-400" />
                <span className="text-cyan-600/40 text-[10px] tracking-wider">TASKS DONE</span>
              </div>
              <div className="text-cyan-400 text-xl font-bold">{completedToday}/{totalToday}</div>
            </div>
            <div className="glass rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <Droplets size={12} className="text-blue-400" />
                <span className="text-cyan-600/40 text-[10px] tracking-wider">WATER</span>
              </div>
              <div className="text-blue-400 text-xl font-bold">{todayWater.toFixed(1)}L</div>
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Chart */}
      <div className="glass rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 size={16} className="text-cyan-400" />
          <span className="text-cyan-400 text-xs font-bold tracking-wider">WEEKLY PERFORMANCE</span>
        </div>
        <canvas ref={canvasRef} className="w-full h-48" />
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Flame size={14} className="text-orange-400 streak-flame" />
            <span className="text-cyan-600/40 text-[10px] tracking-wider">CURRENT STREAK</span>
          </div>
          <div className="text-2xl font-bold text-orange-400">{streak.current} DAYS</div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Trophy size={14} className="text-yellow-400" />
            <span className="text-cyan-600/40 text-[10px] tracking-wider">BEST STREAK</span>
          </div>
          <div className="text-2xl font-bold text-yellow-400">{streak.best} DAYS</div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp size={14} className="text-cyan-400" />
            <span className="text-cyan-600/40 text-[10px] tracking-wider">MONTHLY RATE</span>
          </div>
          <div className="text-2xl font-bold text-cyan-400">{monthRate}%</div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap size={14} className="text-green-400" />
            <span className="text-cyan-600/40 text-[10px] tracking-wider">CONSISTENCY</span>
          </div>
          <div className="text-2xl font-bold text-green-400">
            {monthRate >= 80 ? 'HIGH' : monthRate >= 50 ? 'MODERATE' : 'LOW'}
          </div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Droplets size={14} className="text-blue-400" />
            <span className="text-cyan-600/40 text-[10px] tracking-wider">WEEK AVG</span>
          </div>
          <div className="text-2xl font-bold text-blue-400">
            {(weekData.reduce((a, b) => a + b.percent, 0) / weekData.length).toFixed(0)}%
          </div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Target size={14} className="text-purple-400" />
            <span className="text-cyan-600/40 text-[10px] tracking-wider">WATER GOAL</span>
          </div>
          <div className="text-2xl font-bold text-purple-400">
            {Math.round((todayWater / waterGoal) * 100)}%
          </div>
        </div>
      </div>
    </div>
  );
}
