import { ListTodo, CheckCircle2, Circle, ArrowUp, ArrowDown, Clock, CheckCheck } from 'lucide-react';

interface TodoTask {
  id: string;
  text: string;
  category: 'urgent' | 'important' | 'later' | 'done';
}

interface Props {
  tasks: TodoTask[];
  completedIds: string[];
  onToggle: (id: string) => void;
}

export function TodoPage({ tasks, completedIds, onToggle }: Props) {
  const categories: { key: TodoTask['category']; label: string; icon: React.ElementType; color: string }[] = [
    { key: 'urgent', label: 'URGENT', icon: ArrowUp, color: '#ff0044' },
    { key: 'important', label: 'IMPORTANT', icon: ArrowDown, color: '#ffcc00' },
    { key: 'later', label: 'LATER', icon: Clock, color: '#0080ff' },
    { key: 'done', label: 'DONE', icon: CheckCheck, color: '#00ff88' },
  ];

  const totalTasks = tasks.length;
  const completedCount = tasks.filter((t) => completedIds.includes(t.id)).length;
  const percent = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;

  return (
    <div className="space-y-6 fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-wider text-cyan-400 glow-text flex items-center gap-3">
            <ListTodo size={24} />
            TO-DO LIST
          </h2>
          <p className="text-cyan-600/40 text-xs tracking-wider mt-1">
            MANAGE THROUGH SETTINGS // VIEW ONLY HERE
          </p>
        </div>
        <div className="glass rounded-lg px-4 py-2 flex items-center gap-3">
          <div className="text-right">
            <div className="text-cyan-400 text-lg font-bold">{percent}%</div>
            <div className="text-cyan-600/40 text-[10px] tracking-wider">COMPLETED</div>
          </div>
          <div className="w-16 h-16 relative">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="38" fill="none" stroke="rgba(0,212,255,0.1)" strokeWidth="5" />
              <circle
                cx="50" cy="50" r="38" fill="none" stroke="#00d4ff"
                strokeWidth="5" strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 38}`}
                strokeDashoffset={`${2 * Math.PI * 38 * (1 - percent / 100)}`}
                className="progress-ring-circle"
              />
            </svg>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const catTasks = tasks.filter((t) =>
            cat.key === 'done'
              ? completedIds.includes(t.id)
              : t.category === cat.key && !completedIds.includes(t.id)
          );
          if (cat.key === 'done' && catTasks.length === 0) return null;

          return (
            <div
              key={cat.key}
              className="glass rounded-xl overflow-hidden"
              style={{ borderColor: `${cat.color}20` }}
            >
              <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor: `${cat.color}15` }}>
                <div className="flex items-center gap-2">
                  <Icon size={14} style={{ color: cat.color }} />
                  <span className="text-xs font-bold tracking-wider" style={{ color: cat.color }}>
                    {cat.label}
                  </span>
                </div>
                <span className="text-xs" style={{ color: `${cat.color}80` }}>
                  {catTasks.length}
                </span>
              </div>
              <div className="divide-y divide-cyan-500/5 max-h-80 overflow-y-auto">
                {catTasks.length === 0 ? (
                  <div className="px-4 py-6 text-center text-cyan-700/30 text-xs tracking-wider">
                    NO TASKS IN THIS CATEGORY
                  </div>
                ) : (
                  catTasks.map((task) => {
                    const isDone = completedIds.includes(task.id);
                    return (
                      <div
                        key={task.id}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-cyan-500/5 transition-colors group cursor-pointer"
                        onClick={() => onToggle(task.id)}
                      >
                        {isDone ? (
                          <CheckCircle2 className="flex-shrink-0" size={18} style={{ color: '#00ff88' }} />
                        ) : (
                          <Circle
                            className="flex-shrink-0 text-cyan-700/30 group-hover:text-cyan-500/50 transition-colors"
                            size={18}
                          />
                        )}
                        <span
                          className={`text-sm flex-1 ${
                            isDone ? 'line-through text-cyan-700/30' : 'text-cyan-100/80'
                          }`}
                        >
                          {task.text}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>

      {totalTasks === 0 && (
        <div className="glass rounded-xl p-12 text-center">
          <ListTodo className="mx-auto text-cyan-700/20 mb-4" size={48} />
          <div className="text-cyan-600/30 text-sm tracking-wider">NO TASKS CONFIGURED</div>
          <div className="text-cyan-700/20 text-xs mt-2">Add tasks in Settings</div>
        </div>
      )}
    </div>
  );
}
