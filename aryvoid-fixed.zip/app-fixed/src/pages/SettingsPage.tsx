import { useState } from 'react';
import {
  Settings,
  Plus,
  Trash2,
  Download,
  Upload,
  AlertTriangle,
  Check,
  X,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Box,
  RefreshCw,
  Clock,
  Droplets,
} from 'lucide-react';

interface RoutineTask {
  id: string;
  text: string;
  officeOnly?: boolean;
}

interface TodoTask {
  id: string;
  text: string;
  category: 'urgent' | 'important' | 'later';
}

interface Props {
  waterGoal: number;
  wakeUpTime: string;
  sleepTime: string;
  voiceEnabled: boolean;
  listenEnabled: boolean;
  effects3D: boolean;
  themeIntensity: number;
  routineTasks: RoutineTask[];
  todoTasks: TodoTask[];
  lastBackup: string | null;
  onSetWaterGoal: (v: number) => void;
  onSetWakeUpTime: (v: string) => void;
  onSetSleepTime: (v: string) => void;
  onToggleVoice: () => void;
  onToggleListen: () => void;
  onToggle3D: () => void;
  onSetThemeIntensity: (v: number) => void;
  onAddRoutineTask: (text: string, officeOnly: boolean) => void;
  onDeleteRoutineTask: (id: string) => void;
  onAddTodoTask: (text: string, category: 'urgent' | 'important' | 'later') => void;
  onDeleteTodoTask: (id: string) => void;
  onExport: () => void;
  onImport: (data: string) => boolean;
  onReset: () => void;
}

export function SettingsPage({
  waterGoal,
  wakeUpTime,
  sleepTime,
  voiceEnabled,
  listenEnabled,
  effects3D,
  themeIntensity,
  routineTasks,
  todoTasks,
  lastBackup,
  onSetWaterGoal,
  onSetWakeUpTime,
  onSetSleepTime,
  onToggleVoice,
  onToggleListen,
  onToggle3D,
  onSetThemeIntensity,
  onAddRoutineTask,
  onDeleteRoutineTask,
  onAddTodoTask,
  onDeleteTodoTask,
  onExport,
  onImport,
  onReset,
}: Props) {
  const [activeTab, setActiveTab] = useState<'tasks' | 'preferences' | 'data'>('tasks');
  const [newRoutineText, setNewRoutineText] = useState('');
  const [newRoutineOffice, setNewRoutineOffice] = useState(false);
  const [newTodoText, setNewTodoText] = useState('');
  const [newTodoCategory, setNewTodoCategory] = useState<'urgent' | 'important' | 'later'>('important');
  const [importText, setImportText] = useState('');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [importSuccess, setImportSuccess] = useState(false);

  const handleImport = () => {
    if (!importText.trim()) return;
    const success = onImport(importText);
    setImportSuccess(success);
    if (success) setImportText('');
    setTimeout(() => setImportSuccess(false), 3000);
  };

  const tabs = [
    { id: 'tasks' as const, label: 'TASKS' },
    { id: 'preferences' as const, label: 'PREFERENCES' },
    { id: 'data' as const, label: 'DATA' },
  ];

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h2 className="text-xl font-bold tracking-wider text-cyan-400 glow-text flex items-center gap-3">
          <Settings size={24} />
          CONTROL CENTER
        </h2>
        <p className="text-cyan-600/40 text-xs tracking-wider mt-1">
          CONFIGURE SYSTEM PARAMETERS
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg text-xs tracking-wider font-bold transition-all ${
              activeTab === tab.id ? 'tab-active' : 'tab-inactive'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tasks Tab */}
      {activeTab === 'tasks' && (
        <div className="space-y-6">
          {/* Routine Tasks */}
          <div className="glass rounded-xl p-5">
            <div className="text-cyan-400 text-xs font-bold tracking-wider mb-4">
              ROUTINE TASKS MANAGEMENT
            </div>

            <div className="flex flex-col md:flex-row gap-2 mb-4">
              <input
                className="aryvoid-input flex-1"
                placeholder="New routine task..."
                value={newRoutineText}
                onChange={(e) => setNewRoutineText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newRoutineText.trim()) {
                    onAddRoutineTask(newRoutineText, newRoutineOffice);
                    setNewRoutineText('');
                    setNewRoutineOffice(false);
                  }
                }}
              />
              <label className="flex items-center gap-2 px-3 py-2 text-xs text-cyan-500/60 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={newRoutineOffice}
                  onChange={(e) => setNewRoutineOffice(e.target.checked)}
                  className="custom-checkbox"
                />
                Office only
              </label>
              <button
                onClick={() => {
                  if (!newRoutineText.trim()) return;
                  onAddRoutineTask(newRoutineText, newRoutineOffice);
                  setNewRoutineText('');
                  setNewRoutineOffice(false);
                }}
                className="aryvoid-btn flex items-center gap-1 text-sm"
              >
                <Plus size={14} /> ADD
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {routineTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between px-3 py-2 rounded-lg bg-cyan-500/5 border border-cyan-500/10"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-100/80 text-sm">{task.text}</span>
                    {task.officeOnly && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400/60 border border-cyan-500/20">
                        OFFICE
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => onDeleteRoutineTask(task.id)}
                    className="p-1.5 rounded hover:bg-red-500/10 text-red-500/40 hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
              {routineTasks.length === 0 && (
                <div className="text-cyan-700/30 text-xs text-center py-4">NO CUSTOM ROUTINE TASKS</div>
              )}
            </div>
          </div>

          {/* To-Do Tasks */}
          <div className="glass rounded-xl p-5">
            <div className="text-cyan-400 text-xs font-bold tracking-wider mb-4">
              TO-DO TASKS MANAGEMENT
            </div>

            <div className="flex flex-col md:flex-row gap-2 mb-4">
              <input
                className="aryvoid-input flex-1"
                placeholder="New to-do task..."
                value={newTodoText}
                onChange={(e) => setNewTodoText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newTodoText.trim()) {
                    onAddTodoTask(newTodoText, newTodoCategory);
                    setNewTodoText('');
                  }
                }}
              />
              <select
                className="aryvoid-input text-xs"
                value={newTodoCategory}
                onChange={(e) => setNewTodoCategory(e.target.value as any)}
              >
                <option value="urgent">URGENT</option>
                <option value="important">IMPORTANT</option>
                <option value="later">LATER</option>
              </select>
              <button
                onClick={() => {
                  if (!newTodoText.trim()) return;
                  onAddTodoTask(newTodoText, newTodoCategory);
                  setNewTodoText('');
                }}
                className="aryvoid-btn flex items-center gap-1 text-sm"
              >
                <Plus size={14} /> ADD
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {todoTasks.map((task) => {
                const catColors = {
                  urgent: 'text-red-400 border-red-500/20 bg-red-500/5',
                  important: 'text-yellow-400 border-yellow-500/20 bg-yellow-500/5',
                  later: 'text-blue-400 border-blue-500/20 bg-blue-500/5',
                };
                return (
                  <div
                    key={task.id}
                    className={`flex items-center justify-between px-3 py-2 rounded-lg border ${catColors[task.category]}`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-cyan-100/80 text-sm">{task.text}</span>
                      <span className="text-[10px] uppercase tracking-wider opacity-60">
                        {task.category}
                      </span>
                    </div>
                    <button
                      onClick={() => onDeleteTodoTask(task.id)}
                      className="p-1.5 rounded hover:bg-red-500/10 text-red-500/40 hover:text-red-400 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                );
              })}
              {todoTasks.length === 0 && (
                <div className="text-cyan-700/30 text-xs text-center py-4">NO TO-DO TASKS</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Preferences Tab */}
      {activeTab === 'preferences' && (
        <div className="space-y-6">
          {/* Water Goal */}
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <Droplets size={16} className="text-blue-400" />
              <span className="text-cyan-400 text-xs font-bold tracking-wider">HYDRATION GOAL</span>
            </div>
            <div className="flex items-center gap-4">
              <input
                type="range"
                min="1"
                max="5"
                step="0.5"
                value={waterGoal}
                onChange={(e) => onSetWaterGoal(parseFloat(e.target.value))}
                className="flex-1 accent-cyan-400"
              />
              <span className="text-cyan-400 text-sm font-bold min-w-[60px] text-right">
                {waterGoal}L
              </span>
            </div>
          </div>

          {/* Sleep/Wake Times */}
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <Clock size={16} className="text-cyan-400" />
              <span className="text-cyan-400 text-xs font-bold tracking-wider">SLEEP SCHEDULE</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-cyan-500/60 text-[10px] tracking-wider mb-1 block">
                  WAKE UP TARGET
                </label>
                <input
                  type="time"
                  className="aryvoid-input w-full"
                  value={wakeUpTime}
                  onChange={(e) => onSetWakeUpTime(e.target.value)}
                />
              </div>
              <div>
                <label className="text-cyan-500/60 text-[10px] tracking-wider mb-1 block">
                  SLEEP TARGET
                </label>
                <input
                  type="time"
                  className="aryvoid-input w-full"
                  value={sleepTime}
                  onChange={(e) => onSetSleepTime(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Toggles */}
          <div className="glass rounded-xl p-5 space-y-4">
            <div className="text-cyan-400 text-xs font-bold tracking-wider mb-2">SYSTEM TOGGLES</div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {voiceEnabled ? <Volume2 size={18} className="text-cyan-400" /> : <VolumeX size={18} className="text-cyan-700/30" />}
                <div>
                  <div className="text-cyan-100 text-sm">Voice Effects</div>
                  <div className="text-cyan-600/30 text-[10px]">Jarvis-style audio feedback</div>
                </div>
              </div>
              <button
                onClick={onToggleVoice}
                className={`w-12 h-6 rounded-full transition-all relative ${
                  voiceEnabled ? 'bg-cyan-500/40' : 'bg-cyan-900/20'
                }`}
              >
                <div
                  className={`absolute top-1 w-4 h-4 rounded-full transition-all ${
                    voiceEnabled ? 'left-7 bg-cyan-400' : 'left-1 bg-cyan-700/30'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {listenEnabled ? <Mic size={18} className="text-green-400" /> : <MicOff size={18} className="text-cyan-700/30" />}
                <div>
                  <div className="text-cyan-100 text-sm">Voice Commands</div>
                  <div className="text-cyan-600/30 text-[10px]">Continuous listening mode</div>
                </div>
              </div>
              <button
                onClick={onToggleListen}
                className={`w-12 h-6 rounded-full transition-all relative ${
                  listenEnabled ? 'bg-green-500/40' : 'bg-cyan-900/20'
                }`}
              >
                <div
                  className={`absolute top-1 w-4 h-4 rounded-full transition-all ${
                    listenEnabled ? 'left-7 bg-green-400' : 'left-1 bg-cyan-700/30'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Box size={18} className={effects3D ? 'text-purple-400' : 'text-cyan-700/30'} />
                <div>
                  <div className="text-cyan-100 text-sm">3D Effects</div>
                  <div className="text-cyan-600/30 text-[10px]">Parallax & tilt animations</div>
                </div>
              </div>
              <button
                onClick={onToggle3D}
                className={`w-12 h-6 rounded-full transition-all relative ${
                  effects3D ? 'bg-purple-500/40' : 'bg-cyan-900/20'
                }`}
              >
                <div
                  className={`absolute top-1 w-4 h-4 rounded-full transition-all ${
                    effects3D ? 'left-7 bg-purple-400' : 'left-1 bg-cyan-700/30'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Theme Intensity */}
          <div className="glass rounded-xl p-5">
            <div className="text-cyan-400 text-xs font-bold tracking-wider mb-4">
              THEME INTENSITY
            </div>
            <div className="flex gap-2">
              {[
                { value: 1, label: 'LOW' },
                { value: 2, label: 'MEDIUM' },
                { value: 3, label: 'HIGH' },
                { value: 4, label: 'EXTREME' },
              ].map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => onSetThemeIntensity(opt.value)}
                  className={`flex-1 py-2 rounded-lg text-xs tracking-wider font-bold transition-all ${
                    themeIntensity === opt.value
                      ? 'bg-cyan-500/20 border border-cyan-500/40 text-cyan-400'
                      : 'border border-cyan-500/10 text-cyan-600/30 hover:border-cyan-500/30'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Data Tab */}
      {activeTab === 'data' && (
        <div className="space-y-6">
          {/* Export */}
          <div className="glass rounded-xl p-5">
            <div className="text-cyan-400 text-xs font-bold tracking-wider mb-4">
              EXPORT DATA
            </div>
            <button
              onClick={onExport}
              className="aryvoid-btn flex items-center gap-2 text-sm"
            >
              <Download size={16} /> DOWNLOAD JSON BACKUP
            </button>
            {lastBackup && (
              <div className="text-cyan-600/30 text-[10px] mt-2">
                Last backup: {lastBackup}
              </div>
            )}
          </div>

          {/* Import */}
          <div className="glass rounded-xl p-5">
            <div className="text-cyan-400 text-xs font-bold tracking-wider mb-4">
              IMPORT DATA
            </div>
            <textarea
              className="aryvoid-input w-full min-h-[80px] resize-none text-xs font-mono"
              placeholder="Paste JSON backup data here..."
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
            />
            <div className="flex items-center gap-3 mt-3">
              <button
                onClick={handleImport}
                disabled={!importText.trim()}
                className="aryvoid-btn flex items-center gap-2 text-sm disabled:opacity-30"
              >
                <Upload size={16} /> IMPORT
              </button>
              {importSuccess && (
                <span className="text-green-400 text-xs flex items-center gap-1">
                  <Check size={14} /> IMPORT SUCCESSFUL
                </span>
              )}
            </div>
          </div>

          {/* Reset */}
          <div className="glass rounded-xl p-5 border border-red-500/10">
            <div className="text-red-400 text-xs font-bold tracking-wider mb-4 flex items-center gap-2">
              <AlertTriangle size={14} /> DANGER ZONE
            </div>

            {!showResetConfirm ? (
              <button
                onClick={() => setShowResetConfirm(true)}
                className="aryvoid-btn-danger flex items-center gap-2 text-sm"
              >
                <RefreshCw size={16} /> RESET ALL DATA
              </button>
            ) : (
              <div className="space-y-3">
                <div className="text-red-400/60 text-xs">
                  ARE YOU SURE? ALL DATA WILL BE PERMANENTLY DELETED.
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      onReset();
                      setShowResetConfirm(false);
                    }}
                    className="aryvoid-btn-danger flex items-center gap-1 text-xs"
                  >
                    <Check size={14} /> CONFIRM RESET
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="aryvoid-btn flex items-center gap-1 text-xs"
                  >
                    <X size={14} /> CANCEL
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
