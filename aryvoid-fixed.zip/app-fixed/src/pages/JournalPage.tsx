import { useState } from 'react';
import { BookOpen, Save, Trash2, Edit2, X, ChevronDown, ChevronUp, Clock } from 'lucide-react';

export interface JournalEntry {
  id: string;
  content: string;
  mood: number;
  timestamp: number;
}

interface Props {
  entries: JournalEntry[];
  onAdd: (content: string, mood: number) => void;
  onEdit: (id: string, content: string, mood: number) => void;
  onDelete: (id: string) => void;
}

const moods = [
  { emoji: '😠', label: 'FRUSTRATED', color: '#ff0044' },
  { emoji: '😐', label: 'NEUTRAL', color: '#ffcc00' },
  { emoji: '🙂', label: 'GOOD', color: '#88ff00' },
  { emoji: '😊', label: 'HAPPY', color: '#00ff88' },
  { emoji: '🔥', label: 'ELITE', color: '#00d4ff' },
];

export function JournalPage({ entries, onAdd, onEdit, onDelete }: Props) {
  const [content, setContent] = useState('');
  const [mood, setMood] = useState(2);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const handleSave = () => {
    if (!content.trim()) return;
    if (editingId) {
      onEdit(editingId, content, mood);
      setEditingId(null);
    } else {
      onAdd(content, mood);
    }
    setContent('');
    setMood(2);
  };

  const startEdit = (entry: JournalEntry) => {
    setContent(entry.content);
    setMood(entry.mood);
    setEditingId(entry.id);
    setExpandedId(entry.id);
  };

  const cancelEdit = () => {
    setContent('');
    setMood(2);
    setEditingId(null);
  };

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h2 className="text-xl font-bold tracking-wider text-cyan-400 glow-text flex items-center gap-3">
          <BookOpen size={24} />
          JOURNAL NOTE
        </h2>
        <p className="text-cyan-600/40 text-xs tracking-wider mt-1">
          PERSONAL DIARY // MOOD TRACKING // TIMESTAMPED ENTRIES
        </p>
      </div>

      {/* Entry Form */}
      <div className="glass rounded-xl p-5 glow-cyan-sm space-y-4">
        <div className="text-cyan-400 text-xs font-bold tracking-wider">
          {editingId ? 'EDIT ENTRY' : 'NEW ENTRY'}
        </div>

        <textarea
          className="aryvoid-input w-full min-h-[120px] resize-none"
          placeholder="Record your thoughts, plans, reflections..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />

        <div>
          <div className="text-cyan-500/60 text-[10px] tracking-wider mb-2">MOOD STATE</div>
          <div className="flex gap-3">
            {moods.map((m, i) => (
              <button
                key={i}
                onClick={() => setMood(i)}
                className={`mood-btn ${mood === i ? 'selected' : ''}`}
                title={m.label}
              >
                {m.emoji}
              </button>
            ))}
          </div>
          <div className="text-xs mt-1" style={{ color: moods[mood].color }}>
            {moods[mood].label}
          </div>
        </div>

        <div className="flex gap-2 justify-end">
          {editingId && (
            <button onClick={cancelEdit} className="aryvoid-btn-danger flex items-center gap-2 text-sm">
              <X size={16} /> CANCEL
            </button>
          )}
          <button
            onClick={handleSave}
            disabled={!content.trim()}
            className="aryvoid-btn-success flex items-center gap-2 text-sm disabled:opacity-30"
          >
            <Save size={16} /> {editingId ? 'UPDATE' : 'SAVE ENTRY'}
          </button>
        </div>
      </div>

      {/* Entries List */}
      <div className="space-y-3">
        {entries.map((entry) => {
          const isExpanded = expandedId === entry.id;
          const moodData = moods[entry.mood];
          const preview = entry.content.slice(0, 100);
          return (
            <div
              key={entry.id}
              className="glass rounded-xl overflow-hidden transition-all duration-300"
              style={{
                transform: isExpanded ? 'scale(1.01)' : 'scale(1)',
                borderColor: isExpanded ? 'rgba(0, 212, 255, 0.2)' : undefined,
              }}
            >
              <div
                className="p-4 cursor-pointer"
                onClick={() => setExpandedId(isExpanded ? null : entry.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">{moodData.emoji}</span>
                    <div>
                      <div className="text-cyan-100 text-xs font-bold tracking-wider">
                        {formatDate(entry.timestamp)}
                      </div>
                      <div className="flex items-center gap-1 text-cyan-700/40 text-[10px]">
                        <Clock size={10} />
                        {formatTime(entry.timestamp)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className="text-[10px] px-2 py-0.5 rounded border"
                      style={{
                        color: moodData.color,
                        borderColor: `${moodData.color}40`,
                      }}
                    >
                      {moodData.label}
                    </span>
                    {isExpanded ? (
                      <ChevronUp size={14} className="text-cyan-500/40" />
                    ) : (
                      <ChevronDown size={14} className="text-cyan-500/40" />
                    )}
                  </div>
                </div>

                {!isExpanded ? (
                  <div className="text-cyan-200/60 text-sm pl-9">
                    {entry.content.length > 100 ? preview + '...' : preview}
                  </div>
                ) : (
                  <div className="text-cyan-100/80 text-sm pl-9 mt-3 whitespace-pre-wrap leading-relaxed">
                    {entry.content}
                  </div>
                )}
              </div>

              {isExpanded && (
                <div className="px-4 pb-4 pl-14 flex gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      startEdit(entry);
                    }}
                    className="aryvoid-btn flex items-center gap-1 text-xs py-1.5 px-3"
                  >
                    <Edit2 size={12} /> EDIT
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(entry.id);
                      if (expandedId === entry.id) setExpandedId(null);
                    }}
                    className="aryvoid-btn-danger flex items-center gap-1 text-xs py-1.5 px-3"
                  >
                    <Trash2 size={12} /> DELETE
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {entries.length === 0 && (
        <div className="glass rounded-xl p-12 text-center">
          <BookOpen className="mx-auto text-cyan-700/20 mb-4" size={48} />
          <div className="text-cyan-600/30 text-sm tracking-wider">NO ENTRIES YET</div>
          <div className="text-cyan-700/20 text-xs mt-2">Start writing your first journal entry</div>
        </div>
      )}
    </div>
  );
}
