import { useMemo, useState } from 'react';
import {
  Droplets,
  Sun,
  Sunrise,
  Sunset,
  Moon,
  CheckCircle2,
  Circle,
  ExternalLink,
  BookOpen,
  Brain,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  isMonday,
  isSunday,
  getSeason,
  getDayName,
  getTodayKey,
} from '@/hooks/useLocalStorage';

interface RoutineTask {
  id: string;
  text: string;
  time?: string;
  officeOnly?: boolean;
  link?: string;
  linkLabel?: string;
}

interface RoutineBlock {
  title: string;
  icon: React.ElementType;
  time: string;
  tasks: RoutineTask[];
}

interface Props {
  routineData: Record<string, boolean>;
  waterData: Record<string, number>;
  waterGoal: number;
  customTasks: RoutineTask[];
  onToggleTask: (taskId: string) => void;
  onUpdateWater: (amount: number) => void;
}

export function RoutinePage({
  routineData,
  waterData,
  waterGoal,
  customTasks,
  onToggleTask,
  onUpdateWater,
}: Props) {
  const today = getTodayKey();
  const dayName = getDayName();
  const season = getSeason();
  const isRestDay = isMonday();
  const isWeekendSunday = isSunday();

  const [collapsedBlocks, setCollapsedBlocks] = useState<Set<string>>(new Set());

  const toggleBlock = (title: string) => {
    setCollapsedBlocks((prev) => {
      const next = new Set(prev);
      if (next.has(title)) next.delete(title);
      else next.add(title);
      return next;
    });
  };

  const todayWater = waterData[today] || 0;
  const waterPercent = Math.min(100, (todayWater / waterGoal) * 100);

  const seasonalNote = useMemo(() => {
    switch (season) {
      case 'winter':
        return 'WINTER PROTOCOL: Exercise +15min, Wake up 6:30 AM allowed';
      case 'summer':
        return 'SUMMER PROTOCOL: Wake up 5:30 AM, +1 Water intake';
      case 'monsoon':
        return 'MONSOON PROTOCOL: Indoor exercise focus';
      case 'exam':
        return 'EXAM PROTOCOL: Extra study blocks, reduced office tasks';
      default:
        return '';
    }
  }, [season]);

  const defaultBlocks: RoutineBlock[] = useMemo(() => {
    const blocks: RoutineBlock[] = [
      {
        title: 'MORNING BLOCK',
        icon: Sunrise,
        time: '6:00 AM - 10:00 AM',
        tasks: [
          { id: 'wake', text: 'Wake Up @ 6:00 AM' },
          { id: 'water', text: 'Water Intake - 500ml', time: 'ongoing' },
          { id: 'exercise', text: 'Running / Exercises (30-45 min)' },
          { id: 'bath', text: 'Bath & Fresh Up' },
          { id: 'breakfast', text: 'Light Breakfast + Protein' },
          { id: 'study1', text: 'BCA Study Block 1 (2 hours)' },
        ],
      },
      {
        title: 'MIDDAY BLOCK',
        icon: Sun,
        time: '10:00 AM - 2:00 PM',
        tasks: [
          { id: 'chores', text: 'House Work / Chores' },
          {
            id: 'office',
            text: 'Go to Office (Tue-Sat only)',
            officeOnly: true,
          },
          {
            id: 'ytask',
            text: 'Office Task: Complete specific YouTube video',
            officeOnly: true,
            link: 'https://youtube.com',
            linkLabel: 'Open YouTube',
          },
        ],
      },
      {
        title: 'AFTERNOON BLOCK',
        icon: Sunset,
        time: '2:00 PM - 6:00 PM',
        tasks: [
          {
            id: 'owork',
            text: 'Office work / Professional tasks',
            officeOnly: true,
          },
          {
            id: 'mindset',
            text: 'Ayanokoji Mindset Training Video',
            link: 'https://www.youtube.com/results?search_query=ayanokoji+kiyotaka+mindset+stoicism+discipline',
            linkLabel: 'Search Videos',
          },
          { id: 'walk', text: 'Short Walk / Break' },
        ],
      },
      {
        title: 'EVENING BLOCK',
        icon: Moon,
        time: '6:00 PM - 10:00 PM',
        tasks: [
          {
            id: 'coding',
            text: 'After Office: Coding / Projects',
            officeOnly: true,
          },
          {
            id: 'deepstudy',
            text: 'Deep Study - Python / Linux / Networking / Cyber Security',
          },
          { id: 'journal', text: 'Journal Writing' },
          { id: 'dinner', text: 'Dinner + Family Time' },
          { id: 'review', text: "Review Tomorrow's Plan" },
          { id: 'sleep', text: 'Sleep @ 10:00 PM (8 Hours Target)' },
        ],
      },
    ];
    return blocks;
  }, []);

  const visibleTasks = useMemo(() => {
    if (isRestDay) {
      // Rest day: show non-office tasks only (office tasks suspended)
      // This ensures all time blocks appear with their relevant tasks
      return defaultBlocks.map((block) => ({
        ...block,
        tasks: block.tasks.filter((t) => !t.officeOnly),
      })).filter((b) => b.tasks.length > 0);
    }
    if (isWeekendSunday) {
      return defaultBlocks.map((block) => ({
        ...block,
        tasks: block.tasks.filter((t) => !t.officeOnly),
      })).filter((b) => b.tasks.length > 0);
    }
    return defaultBlocks;
  }, [defaultBlocks, isRestDay, isWeekendSunday]);

  const completionPercent = useMemo(() => {
    const allTasks = visibleTasks.flatMap((b) => b.tasks);
    const completed = allTasks.filter((t) => routineData[t.id]).length;
    return allTasks.length > 0 ? Math.round((completed / allTasks.length) * 100) : 0;
  }, [visibleTasks, routineData]);

  return (
    <div className="space-y-6 fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-wider text-cyan-400 glow-text">
            DAILY ROUTINE
          </h2>
          <p className="text-cyan-600/40 text-xs tracking-wider mt-1">
            {dayName.toUpperCase()} // {season.toUpperCase()} SEASON
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="glass rounded-lg px-4 py-2 flex items-center gap-3">
            <div className="relative w-12 h-12">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(0,212,255,0.1)" strokeWidth="6" />
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="#00d4ff"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - completionPercent / 100)}`}
                  className="progress-ring-circle"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-cyan-400 text-[10px] font-bold">
                {completionPercent}%
              </div>
            </div>
            <div className="text-xs text-cyan-500/60 tracking-wider">TODAY'S<br />PROGRESS</div>
          </div>
        </div>
      </div>

      {/* Banners */}
      {isRestDay && (
        <div className="glass rounded-lg p-4 border border-green-500/30 bg-green-500/5">
          <div className="flex items-center gap-3">
            <Brain className="text-green-400" size={20} />
            <div>
              <div className="text-green-400 text-sm font-bold tracking-wider">
                SYSTEM REST DAY
              </div>
              <div className="text-green-400/50 text-xs">
                PROTOCOL: RECOVERY & DEEP LEARNING // Office tasks suspended
              </div>
            </div>
          </div>
        </div>
      )}

      {isWeekendSunday && (
        <div className="glass rounded-lg p-4 border border-cyan-500/20">
          <div className="text-cyan-400/60 text-xs tracking-wider">
            SYSTEM MAINTENANCE DAY // Deep study + personal projects only
          </div>
        </div>
      )}

      {seasonalNote && (
        <div className="glass rounded-lg p-3 border border-yellow-500/20">
          <div className="text-yellow-400/60 text-xs tracking-wider flex items-center gap-2">
            <Sun size={12} />
            {seasonalNote}
          </div>
        </div>
      )}

      {/* Water Tracker */}
      <div className="glass rounded-xl p-5 glow-cyan-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <Droplets className="text-cyan-400" size={20} />
            <span className="text-cyan-400 text-sm font-bold tracking-wider">HYDRATION TRACKER</span>
          </div>
          <span className="text-cyan-400/60 text-xs">
            {todayWater.toFixed(1)}L / {waterGoal}L
          </span>
        </div>
        <div className="w-full h-3 bg-cyan-900/20 rounded-full overflow-hidden mb-3">
          <div
            className="water-fill h-full rounded-full relative"
            style={{ width: `${waterPercent}%` }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-white/20" />
          </div>
        </div>
        <div className="flex gap-2">
          <button onClick={() => onUpdateWater(0.25)} className="aryvoid-btn text-xs py-1.5 px-3">
            +250ml
          </button>
          <button onClick={() => onUpdateWater(0.5)} className="aryvoid-btn text-xs py-1.5 px-3">
            +500ml
          </button>
          <button onClick={() => onUpdateWater(-0.25)} className="aryvoid-btn-danger text-xs py-1.5 px-3">
            -250ml
          </button>
        </div>
      </div>

      {/* Routine Blocks */}
      <div className="space-y-4">
        {visibleTasks.map((block) => {
          const Icon = block.icon;
          const blockTasks = block.tasks;
          const blockCompleted = blockTasks.filter((t) => routineData[t.id]).length;
          const isAllDone = blockTasks.length > 0 && blockCompleted === blockTasks.length;
          const isCollapsed = collapsedBlocks.has(block.title);
          return (
            <div
              key={block.title}
              className={`glass rounded-xl overflow-hidden transition-all duration-300 ${
                isAllDone ? 'border border-cyan-500/30' : ''
              }`}
            >
              <button
                onClick={() => toggleBlock(block.title)}
                className="w-full px-5 py-3 border-b border-cyan-500/10 flex items-center justify-between hover:bg-cyan-500/5 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={isAllDone ? 'text-cyan-400' : 'text-cyan-500/60'}
                    size={16}
                  />
                  <span className={`text-xs font-bold tracking-wider ${isAllDone ? 'text-cyan-400' : 'text-cyan-400'}`}>
                    {block.title}
                  </span>
                  <span className="text-cyan-600/30 text-[10px]">{block.time}</span>
                  {isAllDone && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      DONE
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs ${isAllDone ? 'text-cyan-400' : 'text-cyan-500/40'}`}>
                    {blockCompleted}/{blockTasks.length}
                  </span>
                  {isCollapsed ? (
                    <ChevronDown className="text-cyan-600/40" size={14} />
                  ) : (
                    <ChevronUp className="text-cyan-600/40" size={14} />
                  )}
                </div>
              </button>
              {!isCollapsed && (
                <div className="divide-y divide-cyan-500/5">
                  {blockTasks.map((task) => {
                    const isDone = routineData[task.id] || false;
                    return (
                      <div
                        key={task.id}
                        className={`flex items-center gap-4 px-5 py-3.5 hover:bg-cyan-500/5 transition-colors group ${
                          isDone ? 'opacity-60' : ''
                        }`}
                      >
                        <button
                          onClick={() => onToggleTask(task.id)}
                          className="flex-shrink-0 active:scale-90 transition-transform"
                        >
                          {isDone ? (
                            <CheckCircle2 className="text-cyan-400" size={20} />
                          ) : (
                            <Circle
                              className="text-cyan-700/30 group-hover:text-cyan-500/50 transition-colors"
                              size={20}
                            />
                          )}
                        </button>
                        <span
                          className={`flex-1 text-sm transition-all ${
                            isDone
                              ? 'line-through text-cyan-700/30'
                              : 'text-cyan-100/80'
                          }`}
                        >
                          {task.text}
                        </span>
                        {task.time && !isDone && (
                          <span className="text-[10px] text-cyan-600/30 tracking-wider">
                            {task.time}
                          </span>
                        )}
                        {task.link && (
                          <a
                            href={task.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-[10px] text-cyan-500/60 hover:text-cyan-400 transition-colors border border-cyan-500/20 hover:border-cyan-500/40 rounded px-2 py-1"
                          >
                            {task.id === 'mindset' ? <Brain size={10} /> : <ExternalLink size={10} />}
                            {task.linkLabel}
                          </a>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Custom Tasks from Settings */}
      {customTasks.length > 0 && (
        <div className="glass rounded-xl overflow-hidden">
          <div className="px-5 py-3 border-b border-cyan-500/10">
            <span className="text-cyan-400 text-xs font-bold tracking-wider">
              CUSTOM TASKS
            </span>
          </div>
          <div className="divide-y divide-cyan-500/5">
            {customTasks.map((task) => {
              const isDone = routineData[task.id] || false;
              return (
                <div
                  key={task.id}
                  className="flex items-center gap-4 px-5 py-3.5 hover:bg-cyan-500/5 transition-colors group"
                >
                  <button onClick={() => onToggleTask(task.id)} className="flex-shrink-0">
                    {isDone ? (
                      <CheckCircle2 className="text-cyan-400" size={20} />
                    ) : (
                      <Circle
                        className="text-cyan-700/30 group-hover:text-cyan-500/50 transition-colors"
                        size={20}
                      />
                    )}
                  </button>
                  <span
                    className={`flex-1 text-sm ${
                      isDone ? 'line-through text-cyan-700/30' : 'text-cyan-100/80'
                    }`}
                  >
                    {task.text}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Monday rest suggestions */}
      {isRestDay && (
        <div className="glass rounded-xl p-5 border border-green-500/20">
          <div className="text-green-400/60 text-xs tracking-wider mb-3">
            SUGGESTED ACTIVITIES FOR REST DAY
          </div>
          <div className="flex flex-wrap gap-2">
            {['Read a book', 'Watch documentary', 'Plan the week'].map((s) => (
              <div
                key={s}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-green-500/20 text-green-400/60 text-xs"
              >
                <BookOpen size={12} />
                {s}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
