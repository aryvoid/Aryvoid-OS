import { useState, useRef, useEffect } from 'react';
import { Shield, Eye, EyeOff, Lock } from 'lucide-react';

interface Props {
  onLogin: () => void;
  speak: (text: string) => void;
  voiceEnabled: boolean;
}

export function LoginPage({ onLogin, speak, voiceEnabled }: Props) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);
  const [typingText, setTypingText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const fullText = 'ARYVOID OPERATING SYSTEM // SECURE ACCESS TERMINAL';

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      if (i <= fullText.length) {
        setTypingText(fullText.slice(0, i));
        i++;
      } else {
        clearInterval(interval);
      }
    }, 40);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'SESHIRONAGI') {
      setLoading(true);
      setError(false);
      if (voiceEnabled) {
        speak('Welcome back, Aryvoid. Systems online. All functions operational.');
      }
      setTimeout(() => {
        onLogin();
      }, 2500);
    } else {
      setError(true);
      if (voiceEnabled) {
        speak('Access failed. Authorization denied. Intruder protocol activated.');
      }
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative">
      {/* Animated HUD rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="absolute w-96 h-96 border border-cyan-500/10 rounded-full hud-rotate" />
        <div className="absolute w-80 h-80 border border-cyan-500/15 rounded-full hud-rotate-reverse" />
        <div className="absolute w-64 h-64 border border-cyan-500/20 rounded-full hud-rotate" style={{ animationDuration: '15s' }} />
        <div className="absolute w-48 h-48 border border-blue-500/10 rounded-full" />
        {/* Corner brackets */}
        <div className="absolute w-[500px] h-[500px]">
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-cyan-500/40" />
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-cyan-500/40" />
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-cyan-500/40" />
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-cyan-500/40" />
        </div>
      </div>

      {/* Login Card */}
      <div
        className={`relative z-10 w-full max-w-md mx-4 ${error ? 'red-alert' : ''}`}
        style={{ perspective: '1000px' }}
      >
        <div className="glass-strong rounded-2xl p-8 glow-cyan-sm">
          {/* Logo */}
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              <div className="w-20 h-20 rounded-full border-2 border-cyan-500/30 flex items-center justify-center">
                <Shield className="text-cyan-400" size={36} />
              </div>
              {loading && (
                <>
                  <div className="absolute inset-0 rounded-full border-2 border-cyan-400/60 pulse-ring" />
                  <div className="absolute -inset-2 rounded-full border border-cyan-500/20 hud-rotate" />
                </>
              )}
            </div>
            <h1 className="text-2xl font-bold tracking-[0.3em] text-cyan-400 glow-text mb-1">
              ARYVOID
            </h1>
            <div className="text-cyan-600/50 text-xs tracking-[0.2em]">
              {typingText}
              <span className="animate-pulse">_</span>
            </div>
          </div>

          {loading ? (
            <div className="flex flex-col items-center gap-4 py-8">
              <div className="relative w-32 h-32">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    fill="none"
                    stroke="rgba(0,212,255,0.1)"
                    strokeWidth="3"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    fill="none"
                    stroke="#00d4ff"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray="264"
                    strokeDashoffset="0"
                    className="progress-ring-circle"
                    style={{
                      animation: 'dash 2s ease-in-out forwards',
                    }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-cyan-400 text-sm font-bold">
                  SYNC
                </div>
              </div>
              <div className="text-cyan-500/60 text-xs tracking-[0.3em]">
                INITIALIZING SYSTEMS...
              </div>
              <div className="flex gap-2">
                {['NEURAL', 'CORE', 'VAULT', 'DATA'].map((label, i) => (
                  <div
                    key={label}
                    className="text-[10px] px-2 py-1 rounded border border-cyan-500/20"
                    style={{
                      color: i < 2 ? '#00d4ff' : 'rgba(0,212,255,0.3)',
                      borderColor: i < 2 ? 'rgba(0,212,255,0.4)' : 'rgba(0,212,255,0.1)',
                      animation: `fadeIn 0.3s ${i * 0.3}s forwards`,
                      opacity: 0,
                    }}
                  >
                    {label}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-cyan-500/60 text-xs tracking-wider">
                    ACCESS CODE
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowHint((h) => !h)}
                    className="text-cyan-700/40 hover:text-cyan-500/60 text-[10px] tracking-wider transition-colors"
                  >
                    {showHint ? 'HIDE HINT' : 'HINT?'}
                  </button>
                </div>
                {showHint && (
                  <div className="mb-2 text-[10px] text-cyan-600/50 tracking-wider px-3 py-2 rounded border border-cyan-500/10 bg-cyan-500/5">
                    Hint: Your favorite Blue Lock character, all caps, no spaces.
                  </div>
                )}
                <div className="relative">
                  <Lock
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-600/40"
                    size={16}
                  />
                  <input
                    ref={inputRef}
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="aryvoid-input w-full pl-10 pr-10"
                    placeholder="Enter access code..."
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-cyan-600/40 hover:text-cyan-400 transition-colors"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="text-red-400 text-xs tracking-wider text-center bg-red-500/10 py-2 rounded border border-red-500/20">
                  ACCESS DENIED // INTRUDER PROTOCOL ACTIVATED
                </div>
              )}

              <button
                type="submit"
                className="w-full aryvoid-btn py-3 text-sm tracking-[0.2em] font-bold"
              >
                AUTHENTICATE
              </button>

              <div className="text-center text-cyan-700/30 text-[10px] tracking-wider">
                OFFLINE MODE // NO EXTERNAL CONNECTIONS
              </div>
            </form>
          )}
        </div>
      </div>

      <style>{`
        @keyframes dash {
          from { stroke-dashoffset: 264; }
          to { stroke-dashoffset: 0; }
        }
      `}</style>
    </div>
  );
}
