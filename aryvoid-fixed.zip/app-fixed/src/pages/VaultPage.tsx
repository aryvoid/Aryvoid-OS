import { useState } from 'react';
import { Shield, Eye, EyeOff, Plus, Trash2, Edit2, X, Check, Lock } from 'lucide-react';

export interface VaultEntry {
  id: string;
  title: string;
  username: string;
  password: string;
}

interface Props {
  entries: VaultEntry[];
  onAdd: (entry: Omit<VaultEntry, 'id'>) => void;
  onEdit: (id: string, entry: Omit<VaultEntry, 'id'>) => void;
  onDelete: (id: string) => void;
}

function obfuscate(text: string): string {
  try {
    return btoa(text);
  } catch {
    return text;
  }
}

function deobfuscate(text: string): string {
  try {
    return atob(text);
  } catch {
    return text;
  }
}

export function VaultPage({ entries, onAdd, onEdit, onDelete }: Props) {
  const [showAdd, setShowAdd] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [visibleIds, setVisibleIds] = useState<Set<string>>(new Set());
  const [form, setForm] = useState({ title: '', username: '', password: '' });
  const [searchTerm, setSearchTerm] = useState('');

  const toggleVisibility = (id: string) => {
    setVisibleIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.password) return;
    if (editingId) {
      onEdit(editingId, {
        title: form.title,
        username: form.username,
        password: obfuscate(form.password),
      });
      setEditingId(null);
    } else {
      onAdd({
        title: form.title,
        username: form.username,
        password: obfuscate(form.password),
      });
    }
    setForm({ title: '', username: '', password: '' });
    setShowAdd(false);
  };

  const startEdit = (entry: VaultEntry) => {
    setForm({
      title: entry.title,
      username: entry.username,
      password: deobfuscate(entry.password),
    });
    setEditingId(entry.id);
    setShowAdd(true);
  };

  const filteredEntries = entries.filter(
    (e) =>
      e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-wider text-cyan-400 glow-text flex items-center gap-3">
            <Shield size={24} />
            VAULT
          </h2>
          <p className="text-cyan-600/40 text-xs tracking-wider mt-1">
            SECURE PASSWORD MANAGER // BASE64 ENCRYPTION
          </p>
        </div>
        <button
          onClick={() => {
            setShowAdd(!showAdd);
            setEditingId(null);
            setForm({ title: '', username: '', password: '' });
          }}
          className="aryvoid-btn flex items-center gap-2 text-sm"
        >
          {showAdd ? <X size={16} /> : <Plus size={16} />}
          {showAdd ? 'CANCEL' : 'ADD ENTRY'}
        </button>
      </div>

      {showAdd && (
        <form onSubmit={handleSubmit} className="glass rounded-xl p-5 glow-cyan-sm space-y-4">
          <div className="text-cyan-400 text-xs font-bold tracking-wider mb-2">
            {editingId ? 'EDIT ENTRY' : 'NEW ENTRY'}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-cyan-500/60 text-[10px] tracking-wider mb-1 block">TITLE</label>
              <input
                className="aryvoid-input w-full"
                placeholder="e.g. Instagram"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div>
              <label className="text-cyan-500/60 text-[10px] tracking-wider mb-1 block">USERNAME</label>
              <input
                className="aryvoid-input w-full"
                placeholder="e.g. example@email.com"
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
              />
            </div>
            <div>
              <label className="text-cyan-500/60 text-[10px] tracking-wider mb-1 block">PASSWORD</label>
              <input
                type="password"
                className="aryvoid-input w-full"
                placeholder="Enter password..."
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button type="submit" className="aryvoid-btn-success flex items-center gap-2 text-sm">
              <Check size={16} />
              {editingId ? 'UPDATE' : 'SAVE'}
            </button>
          </div>
        </form>
      )}

      <input
        className="aryvoid-input w-full"
        placeholder="Search entries..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <div className="space-y-3">
        {filteredEntries.map((entry) => {
          const isVisible = visibleIds.has(entry.id);
          const decryptedPass = deobfuscate(entry.password);
          return (
            <div
              key={entry.id}
              className="glass rounded-xl p-4 flex flex-col md:flex-row md:items-center gap-4 group hover:border-cyan-500/20 transition-all"
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center flex-shrink-0">
                  <Lock size={16} className="text-cyan-400" />
                </div>
                <div className="min-w-0">
                  <div className="text-cyan-100 text-sm font-medium truncate">{entry.title}</div>
                  <div className="text-cyan-600/40 text-xs truncate">{entry.username || 'No username'}</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="glass rounded-lg px-3 py-2 flex items-center gap-2 min-w-[140px]">
                  <span className="text-cyan-300/80 text-sm font-mono">
                    {isVisible ? decryptedPass : '•'.repeat(Math.min(decryptedPass.length, 12))}
                  </span>
                </div>
                <button
                  onClick={() => toggleVisibility(entry.id)}
                  className="p-2 rounded-lg hover:bg-cyan-500/10 transition-colors text-cyan-500/60 hover:text-cyan-400"
                >
                  {isVisible ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
                <button
                  onClick={() => startEdit(entry)}
                  className="p-2 rounded-lg hover:bg-cyan-500/10 transition-colors text-cyan-500/60 hover:text-cyan-400"
                >
                  <Edit2 size={16} />
                </button>
                <button
                  onClick={() => onDelete(entry.id)}
                  className="p-2 rounded-lg hover:bg-red-500/10 transition-colors text-red-500/40 hover:text-red-400"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredEntries.length === 0 && (
        <div className="glass rounded-xl p-12 text-center">
          <Shield className="mx-auto text-cyan-700/20 mb-4" size={48} />
          <div className="text-cyan-600/30 text-sm tracking-wider">
            {searchTerm ? 'NO MATCHING ENTRIES' : 'VAULT IS EMPTY'}
          </div>
        </div>
      )}
    </div>
  );
}
